package com.projetoduplo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.mvc.AbstractController;
import com.projetoduplo.model.Disciplina;
import com.projetoduplo.service.DisciplinaService;
import com.projetoduplo.service.ValidationService;

public class DisciplinaController {
    @Controller
    private long idDisciplina;
    private String nomeDisciplina;
    private String nomeDoProfessor;
    private int cargaHoraria;

    @Autowired
    private DisciplinaService disciplinaService;
    @Autowired
    private ValidationService validationService;

    public String save() {
        if(validationService.validateidDisciplina(idDisciplina) && validationService.validateNomedisciplina(nomeDisciplina)) {
            Disciplina disciplina = new Disciplina();

            disciplina.setNomeDisciplina(nomedisciplina);
            disciplina.setNomeDoProfessor(nomedoProfessor);
            

            disciplinaService.save(disciplina);

            addInfoMessage("Save", String.format("Um novo estudante foi criado. %s", nomeAluno));

            return goToListView();
        } else {
            addErrorMessage("Error", "Nome e/ou idade inválido.");
            return "";
        }
    }
}

